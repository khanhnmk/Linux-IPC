Shared memory Demo
