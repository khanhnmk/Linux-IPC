char* itoa(int num, char* str, int base);
